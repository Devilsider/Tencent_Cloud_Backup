#include <func.h>

int main(int argc,char* argv[])
{
	write(STDOUT_FILENO,"hello",5);
}
