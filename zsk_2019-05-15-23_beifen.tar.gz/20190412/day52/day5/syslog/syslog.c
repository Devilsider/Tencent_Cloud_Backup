#include <func.h>

int main()
{
	syslog(LOG_INFO,"I am dashen %d\n",1);
	return 0;
}
