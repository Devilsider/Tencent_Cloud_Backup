#include <func.h>

int main()
{
	printf("uid=%d,gid=%d\n",getuid(),getgid());
	while(1);
}
