print(3+4)
