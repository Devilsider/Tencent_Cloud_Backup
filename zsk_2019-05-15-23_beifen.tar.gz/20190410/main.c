#include <stdio.h>
int multi_two(int a,int b);
int main()
{
	int a=10;
	int b=20;
	printf("the res is %d\n",multi_two(a,b));
}
