#include <func.h>
int print();
int main(){
	printf("I'm main!\n");
	print();
	print();
	print();
	printf("the end !\n");
return 0;
}
