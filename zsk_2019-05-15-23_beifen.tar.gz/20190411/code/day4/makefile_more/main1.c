#include <stdio.h>

int main()
{
	printf("I am main\n");
	return 0;
}
