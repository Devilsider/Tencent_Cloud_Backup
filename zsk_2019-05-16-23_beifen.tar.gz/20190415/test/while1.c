#include <func.h>
int main(){
	while(1){
		int temp;
		scanf("%d",&temp);
	}
	return 0;
}

