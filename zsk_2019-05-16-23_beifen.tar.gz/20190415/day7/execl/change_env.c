#include <func.h>

int main(int argc,char* argv[])
{
	int i;
	for(i=0;i<argc;i++)
	{
		puts(argv[i]);
	}
	printf("I am print code\n");
	system("echo $PATH");
}
