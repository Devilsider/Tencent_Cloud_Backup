#include <stdio.h>

int main()
{
	int i,j;
	scanf("%d%d",&i,&j);
	printf("sum=%d\n",i+j);
	return 0;
}
