#include <func.h>
int print(){
	printf("I'm the print_function!\n");
return 0;
}
