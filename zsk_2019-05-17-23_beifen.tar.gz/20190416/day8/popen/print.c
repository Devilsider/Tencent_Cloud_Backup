#include <stdio.h>

int main()
{
	printf("I am print function\n");
}
