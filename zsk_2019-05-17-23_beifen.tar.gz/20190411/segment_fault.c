#include<func.h>

void main(){
	char *p;
	*p='Hello world';
}

