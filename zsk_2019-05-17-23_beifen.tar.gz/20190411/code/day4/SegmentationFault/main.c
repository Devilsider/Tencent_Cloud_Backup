#include <stdio.h>

int main()
{
	char *p=NULL;
	*p='H';
	printf("*p=%c\n",*p);
	return 0;
}
