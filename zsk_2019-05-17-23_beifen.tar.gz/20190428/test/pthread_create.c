#include <func.h>
typedef struct{
    int num;
}Data ;
void *threadFunc(void *p){
    
}
int main()
{   
    pthread_t pthId;
    Data da;
    da.num=2;
    void *
    return 0;
}

